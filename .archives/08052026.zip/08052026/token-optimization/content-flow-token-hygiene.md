# Content-flow token hygiene (session-scope cost docs + packaged content-flow defaults)

**Status:** implemented 2026-07-16 **Priority:** P1 **Source:** [2026-07-16 token analysis](../../analysis/2026-07-16-blog-review-happy-in-my-misfortunes-4-token-analysis.md) (F2 doc-follow-up, F3, F5)

Two small, low-risk changes that reduce raw token growth on content flows without touching the engine. Both are safe to ship independently.

## Decisions (resolved 2026-07-16)

- **Fresh `polish` default — ship now.** Change the packaged default to `fresh_disposable` without waiting for A/B: the node is terminal (→ publish) and already receives the diff + reviewer findings as artifacts, so the risk is low. The savings/voice A/B confirms it afterward (and depends on the usage substrate — see the dependency note below).
- **Model/provider after the lineage break — rely on the flow-wide default + update the YAML comment.** `polish` inherits the flow default (the packaged flow pins nothing — all provider/model blocks ship commented), so shipped behavior is unchanged. Rewrite the existing note on the `polish` node (currently "it resumes revise's editing lineage, so it MUST carry the same model/provider…") to say `polish` is now independent and, for voice consistency, should be pinned to the same model as `revise` if `revise` is pinned. No active pin is added.
- **Rollout — ship the packaged default now + note the re-seed gap.** Packaged is the canonical source of truth; the change benefits new installs immediately. There is no `upgrade-flows` re-seed mechanism yet, so existing installs (e.g. the operator's `WastimeApp/.worc/`) need a manual copy to pick it up — call this out in the change.
- **`fixing` stays on the `revise` lineage (confirmed safe).** After the change the editing lineage is `revise → fixing` (rework genuinely benefits); `polish` is peeled off. Verified: `polish` is terminal and no node has `lineage_affinity: polish`, so nothing resumes it — the break is safe. This is the intended shape.
- **Docs canonical location:** the warning text lives in `docs/flow-authoring.md`; the packaged guide (`reference.md` / `README.md`) cross-references it rather than restating it, to avoid three drifting copies.

## Cross-task dependency

Part B's benefit (the ~60–80k saving **and** "quality is no worse") is only measurable via an A/B, and an honest A/B needs the normalized usage from [normalized-usage-accounting.md](normalized-usage-accounting.md). Order of work: land the usage substrate first, then ship + measure this change. The default flip itself does not block on task 1 (decision above), but its confirmation does.

## Part A — warn about the token cost of resumed sessions in the docs

The session-scope docs describe `session_scope` / `lineage_affinity` / `resume` purely as a context-continuity feature and contain **no** warning that resuming a session inherits the full accumulated history and grows input tokens on every subsequent model turn. This is exactly what surprised the operator in the analyzed run: `polish` (declared `lineage_affinity: revise`) re-ran a 31–37k-token transcript four times for a one-word edit.

- Add an explicit token-cost / history-growth note to the session-scope docs: `resume`, `editing_lineage` and `lineage_affinity` carry the shared session's history into the next stage — it preserves context but increases input token usage on every following model turn, so a shared session should be used deliberately, especially between semantically different stages.
- Locations: `docs/flow-authoring.md` ("Editing sessions and lineages", ~124-141) and the shipped operator guide `src/wastech_orchestrator/packaged/guide/flows/reference.md` (session_scope / lineage_affinity rows) + `packaged/guide/flows/README.md`.

## Part B — fix the packaged `blog_article_revise` defaults

`blog_article_revise` is a **packaged built-in** (`src/wastech_orchestrator/packaged/flows/blog_article_revise.yaml`), so its defaults ship from this repo. Two field-safe tweaks:

1. **Break the `revise → polish` lineage.** `polish` is the terminal independent editor; it already receives the diff and reviewer findings as artifacts and has no downstream rework, so it has no reason to own a durable editing lineage. Change its `session_scope` to `fresh_disposable` (drop `lineage_affinity: revise`). Keep `lineage_affinity` only where a rework loop genuinely benefits (e.g. `fixing`). Estimated saving on a comparable pass: ~60–80k raw input tokens (exact number needs A/B, since a fresh session may re-read mandatory rules).
2. **Add an operational read/patch budget to the role prompts.** The packaged role prompts emphasize scope minimalism but carry no operational budget; the run showed the agent re-reading full documents across six model turns for four edits. Add compact guidance to the `blog_article_revise` `revise`/`polish` role prompts (`packaged/flows/blog_article_revise/*.md`): read the brief, target article and findings in one parallel batch; do not re-read a file already present in the session; apply one focused patch, inspect one final diff, then stop. This is guidance, not a hard token limit.

## Acceptance criteria

- [x] Session-scope docs (`flow-authoring.md` + packaged guide) explicitly state that resume/`editing_lineage`/`lineage_affinity` inherit session history and grow per-turn input tokens.
- [x] Packaged `blog_article_revise.yaml` `polish` node is `fresh_disposable` (no `lineage_affinity`), and this is reflected in any flow reference docs.
- [x] Packaged `blog_article_revise` `revise`/`polish` role prompts carry the read-once / one-patch / one-diff operational budget.
- [x] Docs and packaged copies stay in sync (`/sync-docs`); prose is prettier-formatted (`proseWrap: never`).

_Actualized 2026-07-23: all four criteria shipped (`polish` is `fresh_disposable` with the independence comment, `revise.md`/`polish.md` carry the read-once/one-patch/one-diff budget, and the token-cost warning lives in `docs/flow-authoring.md` with cross-references from the packaged guide). Still open — and now unblocked, because its measurement substrate ([normalized-usage-accounting.md](normalized-usage-accounting.md)) is merged: the **A/B confirmation** of the ~60–80k saving and "quality no worse" (see Cross-task dependency below). Existing installed `.worc/` copies still need a manual re-seed — there is no `upgrade-flows` mechanism yet._

## Out of scope

- The operator's already-installed copy in the target repo's `.worc/` — changing the packaged default only affects **future** installs / re-seeds; the copy that actually ran the analyzed task lives in `WastimeApp/.worc/` and is operator-owned. Note this in the change.
- model/effort tuning (`revise xhigh→high`, cheaper Claude roles) — a configuration/A-B decision on the target flow, not a packaged-default code change here.
- Conditional / machine-readable `needs_research` branching — needs new engine machinery; explicitly not part of this task.

## Likely implementation areas

- `docs/flow-authoring.md`
- `src/wastech_orchestrator/packaged/guide/flows/{reference.md,README.md}`
- `src/wastech_orchestrator/packaged/flows/blog_article_revise.yaml`
- `src/wastech_orchestrator/packaged/flows/blog_article_revise/*.md`
